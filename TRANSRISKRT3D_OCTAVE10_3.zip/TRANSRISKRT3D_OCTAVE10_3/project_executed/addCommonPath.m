function addCommonPath()
    currentFolder = fileparts(mfilename('fullpath'));
    rootFolder = fileparts(currentFolder);
    commonPath = fullfile(rootFolder, 'common_functions');
    addpath(commonPath);
end

