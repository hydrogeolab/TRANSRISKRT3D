function filePath = getCommonDataFile(fileName)
    currentFolder = fileparts(mfilename('fullpath'));
    rootFolder = fileparts(currentFolder);
    commonDataPath = fullfile(rootFolder, 'common_data');
    filePath = fullfile(commonDataPath, fileName);
end
