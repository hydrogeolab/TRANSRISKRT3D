function deleteFortFiles(folderPath)
% deleteFortFiles Deletes files like fort.1, fort.2, etc. in a given folder.
%
%   deleteFortFiles(folderPath)
%
%   Inputs:
%       folderPath - Path to the folder where fort.* files should be deleted.
%
%   Example:
%       deleteFortFiles(pwd)  % Deletes in the current directory

    if nargin < 1 || isempty(folderPath)
        folderPath = pwd;  % Default to current folder
    end

    pattern = fullfile(folderPath, 'fort.*');
    files = dir(pattern);

    if isempty(files)
        fprintf('No fort.* files found in: %s\n', folderPath);
        return;
    end

    deletedCount = 0;
    for k = 1:length(files)
        fileToDelete = fullfile(folderPath, files(k).name);
        if exist(fileToDelete, 'file') == 2  % Make sure it's a file
            delete(fileToDelete);
            fprintf('Deleted: %s\n', fileToDelete);
            deletedCount = deletedCount + 1;
        end
    end

    fprintf('Total files deleted: %d\n', deletedCount);
end