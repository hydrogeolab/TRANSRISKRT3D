findX=pdist2([activetrue.X,activetrue.Y],[pz1X,pz1Y]); [IDX1,IDX2]=sort(findX);

hold on
plot(TT(no)/365,R1_inPCE(:,IDX2(1))/beta_indoor_PCE,'-o')
plot(TT(no)/365,R1_inTCE(:,IDX2(1))/beta_indoor_TCE,'-+')
plot(TT(no)/365,R1_inDCE(:,IDX2(1))/beta_indoor_DCE,'-s')
plot(TT(no)/365,R1_inVC(:,IDX2(1))/beta_indoor_VC,'-+')

xlim([0 25])
