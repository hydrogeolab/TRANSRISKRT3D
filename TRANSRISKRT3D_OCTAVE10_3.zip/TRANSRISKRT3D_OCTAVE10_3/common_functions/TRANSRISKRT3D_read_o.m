function [TIME2,C,counto] = TRANSRISKRT3D_read_o (counto,fid)

counto=counto+1;
NTRANS=fread(fid,1,'int32');
KSTP=fread(fid,1,'int32');
KPER=fread(fid,1,'int32');
TIME2=fread(fid,1,'float32');
desc = fread(fid, [16,1], '*char')';
NCOL=fread(fid,1,'int32');
NROW=fread(fid,1,'int32');
ILAY=fread(fid,1,'int32');
count=0;
C=zeros(NROW,NCOL,ILAY);
for K=1:ILAY
    for I=1:NROW
        for J=1:NCOL
            count=count+1;
            Cnow=fread(fid,1,'float32');
            C(I,J,K)=Cnow;
        end
    end
end
end