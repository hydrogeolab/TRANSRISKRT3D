function struct2csv(s, filename)
    fid = fopen(filename, 'w');
    fields = fieldnames(s);
    nFields = numel(fields);

    % Write header
    for i = 1:nFields
        fprintf(fid, '%s', fields{i});
        if i < nFields
            fprintf(fid, ',');
        else
            fprintf(fid, '\n');
        end
    end

    % Write data
    for i = 1:numel(s)
        for j = 1:nFields
            val = s(i).(fields{j});
            if ischar(val)
                fprintf(fid, '%s', val);
            elseif isnumeric(val)
                fprintf(fid, '%g', val);
            elseif islogical(val)
                fprintf(fid, '%d', val);
            else
                fprintf(fid, '');
            end
            if j < nFields
                fprintf(fid, ',');
            else
                fprintf(fid, '\n');
            end
        end
    end
    fclose(fid);
end

