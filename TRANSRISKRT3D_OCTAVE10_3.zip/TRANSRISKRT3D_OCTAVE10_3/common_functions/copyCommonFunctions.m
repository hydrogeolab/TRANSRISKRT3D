function copiedFiles = copyCommonFunctions()
% copyCommonFunctions Copies all files from common_functions to current dir
% and returns the list of copied file names (no paths)

    currentFolder = fileparts(mfilename('fullpath'));
    rootFolder = fileparts(currentFolder);
    sourceFolder = fullfile(rootFolder, 'common_functions');
    destinationFolder = pwd;

    if ~isfolder(sourceFolder)
        error('Source folder does not exist: %s', sourceFolder);
    end

    files = dir(fullfile(sourceFolder, '*.*'));
    files = files(~[files.isdir]);

    copiedFiles = {};  % Initialize

    for k = 1:length(files)
        srcFile = fullfile(sourceFolder, files(k).name);
        destFile = fullfile(destinationFolder, files(k).name);
        copyfile(srcFile, destFile);
        copiedFiles{end+1} = files(k).name; %#ok<AGROW>
        fprintf('Copied: %s → %s\n', srcFile, destFile);
    end

    fprintf('Copied %d files to: %s\n', length(copiedFiles), destinationFolder);
end