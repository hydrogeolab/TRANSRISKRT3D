function copiedFiles = copyCommonData()
% copyCommonData Copies all files from common_data to current directory.
% Returns a list of copied file names.

    currentFolder = fileparts(mfilename('fullpath'));
    rootFolder = fileparts(currentFolder);
    sourceFolder = fullfile(rootFolder, 'common_data');
    destinationFolder = pwd;

    if ~isfolder(sourceFolder)
        error('Source folder does not exist: %s', sourceFolder);
    end

    files = dir(fullfile(sourceFolder, '*.*'));
    files = files(~[files.isdir]);  % Only regular files

    copiedFiles = {};  % List of copied file names

    for k = 1:length(files)
        srcFile = fullfile(sourceFolder, files(k).name);
        destFile = fullfile(destinationFolder, files(k).name);
        copyfile(srcFile, destFile);
        copiedFiles{end+1} = files(k).name; %#ok<AGROW>
        fprintf('Copied: %s → %s\n', srcFile, destFile);
    end

    fprintf('Copied %d data files to: %s\n', length(copiedFiles), destinationFolder);
end
