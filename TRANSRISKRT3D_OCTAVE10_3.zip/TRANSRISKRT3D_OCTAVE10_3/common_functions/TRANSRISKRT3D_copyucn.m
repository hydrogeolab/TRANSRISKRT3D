for ns=1:6
    fileold=horzcat('rt3d00',num2str(ns),'.ucn');
    filenew=horzcat('rt3d00',num2str(ns),'_',num2str(nph),'.ucn');
    copyfile(fileold,filenew);
end