if numoutputs>0
    fileucn=[rootfile,'_',num2str(nph),'.ucn'];
    fid=fopen(fileucn,'rb');
    for no=1:numoutputs
        [TIME2,C,counto] = TRANSRISKRT3D_read_o (counto,fid);
        TT(counto)=TTnow+TIME2;
        for jj=1:actnumel
            Ypz_1=activetrue.Row(jj); % observation I cell 
            Xpz_1=activetrue.Column(jj); % observation J cell
            Cnow=C(Ypz_1,Xpz_1);
            if Cnow>1e10;Ct_1(counto,jj)=0;else; Ct_1(counto,jj)=Cnow;end
        end
    end
    fclose all;
end