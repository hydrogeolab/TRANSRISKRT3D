function active = TRANSRISKRT3D_import_active(filename, dataLines)
  %TRANSRISKRT3D_import_active Import data from a CSV file (Octave compatible)
  %
  % active = TRANSRISKRT3D_import_active(filename)
  % active = TRANSRISKRT3D_import_active(filename, dataLines)

  if nargin < 2
    dataLines = [2, Inf];
  end

  % Open the file
  fid = fopen(filename, 'r');
  if fid == -1
    error('Could not open file: %s', filename);
  end

  % Skip header line
  headerLine = fgetl(fid);

  % Prepare format spec: 8 numeric fields, 1 string/categorical
  formatSpec = '%f%f%f%f%f%f%f%f%s';  % 'Active' field as string

  % Read all data
  data = textscan(fid, formatSpec, 'Delimiter', ',', 'HeaderLines', dataLines(1)-2);

  fclose(fid);

  % Convert to table manually (compatible with Octave)
  active = struct();
  active.X        = data{1};
  active.Y        = data{2};
  active.Z        = data{3};
  active.X_Prime  = data{4};
  active.Y_Prime  = data{5};
  active.Column   = data{6};
  active.Row      = data{7};
  active.Layer    = data{8};
  active.Active   = data{9};  % This is a cell array of strings

  % Convert to a table if table is available
  if exist('table', 'builtin')
    active = table(active.X, active.Y, active.Z, active.X_Prime, active.Y_Prime, ...
                   active.Column, active.Row, active.Layer, active.Active, ...
                   'VariableNames', {'X','Y','Z','X_Prime','Y_Prime','Column','Row','Layer','Active'});
  end

  % Handle dataLines end index if needed
  if ~isinf(dataLines(2))
    numRows = dataLines(2) - dataLines(1) + 1;
    active = active(1:numRows, :);
  end
end

