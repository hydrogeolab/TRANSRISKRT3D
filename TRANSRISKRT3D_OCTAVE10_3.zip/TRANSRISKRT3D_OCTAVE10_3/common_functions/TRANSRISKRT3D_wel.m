Nw = size(wel_matrix, 1);
wel_matrix(:, 4) = wel_matrix(:, 4) .* PT_phase;
fid=fopen('wel.dat','wt');
fprintf(fid,'%i %s\n',Nw,'        50');
fprintf(fid,'%i\n',Nw);
fmt = repmat('%10.6i', 1, 4);
for j=1:Nw
    fprintf(fid, fmt, wel_matrix(j,1),wel_matrix(j,2),wel_matrix(j,3),wel_matrix(j,4));
    fprintf(fid, '\n');
end
fclose all;
