function lines = readlines(filename)
    fid = fopen(filename, 'r');
    if fid == -1
        error('Cannot open file %s', filename);
    end
    lines = {};
    while ~feof(fid)
        lines{end+1,1} = fgetl(fid);
    end
    fclose(fid);
end
