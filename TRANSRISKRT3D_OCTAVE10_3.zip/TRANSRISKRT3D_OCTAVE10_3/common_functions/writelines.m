function writelines(lines, filename)
    fid = fopen(filename, 'w');
    if fid == -1
        error('Cannot open file %s for writing', filename);
    end
    for i = 1:length(lines)
        fprintf(fid, '%s\n', lines{i});
    end
    fclose(fid);
end
