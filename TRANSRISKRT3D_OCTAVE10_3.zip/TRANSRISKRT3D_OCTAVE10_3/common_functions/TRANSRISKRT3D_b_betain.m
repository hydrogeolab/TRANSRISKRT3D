function beta=TRANSRISKRT3D_b_betain(EM,H,Dair,Dwat,IUR,...
    thetaa,thetaw,thetae,thetaacap,thetawcap,thetaecap,Lgw,hcap,...
    thetacrack,thetawcrack,Zcrack,Lcrack,...
    eta,Lb,ER)

% VF_wamb Groundwater: Outdoor Vapors Volatilization 

%Diffusion Coefficient in the vadose zone
thetaa_333=thetaa^3.33;
thetaw_333=thetaw^3.33;
thetae_2=thetae^2;
Deffs=(Dair*thetaa_333/thetae_2)+(Dwat*thetaw_333/(H*thetae_2));

%Diffusion Coefficient in the capillary zone
thetaacap_333=thetaacap^3.33;
thetawcap_333=thetawcap^3.33;
thetaecap_2=thetaecap^2;
Deffcap=(Dair*thetaacap_333/thetaecap_2)+(Dwat*thetawcap_333/(H*thetaecap_2));

%Deffw= Effective diffusivity from groundwater (cm2/s)
hv=Lgw-hcap;
NUM=100*Lgw;
DEN=(100*hcap/Deffcap)+(100*hv/Deffs);
Deffw=NUM/DEN;

%Diffusion Coefficient in the foundations
thetaacrack_333=thetacrack^3.33;
thetawcrack_333=thetawcrack^3.33;
thetaecrack=thetacrack+thetawcrack;
thetaecrack_2=thetaecrack^2;
Deff_crack=(Dair*thetaacrack_333/thetaecrack_2)+(Dwat*thetawcrack_333/(H*thetaecrack_2));

% Groundwater: Indoor Vapors Volatilization 

% assuming no Differential outdoor/indoor air pressure	(Δp=0);
VF_num=H*Deffw/((Lgw-Zcrack)*Lb*100*ER);
VF_DEN1=Deffw/((Lgw-Zcrack)*Lb*100*ER);
VF_DEN2=(Deffw*Lcrack*100)/(Deff_crack*(Lgw-Zcrack)*100*eta);
VFwesp=1000*VF_num/(100*(1+VF_DEN1+VF_DEN2)); % ................... 100 to convert from m to cm

beta=1000*VFwesp*EM*IUR;