Nw=size(wel,1);
load('wel_real.mat');
wel.VarName4(:)=wel.VarName4(:).*PT_phase;
fid=fopen('wel.dat','wt');
fprintf(fid,'%i %s\n',Nw,'        50');
fprintf(fid,'%i\n',Nw);
fmt = repmat('%10.6i', 1, 4);
for j=1:numel(wel.VarName4)
    fprintf(fid, fmt,wel.VarName1(j),wel.VarName2(j),wel.VarName3(j),wel.VarName4(j));
    fprintf(fid, '\n');
end
fclose all;