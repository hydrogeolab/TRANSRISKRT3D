function beta=a_calc_beta_outdoor(EC,deltaair,Wprime,Lgw,...
    thetae,thetaw,thetaa,thetawcap,thetaacap,hcap,Uair,H,Dair,Dwat,IUR)

thetaecap=thetawcap+thetaacap;
hv=Lgw-hcap; %[m] Unsaturated zone thickness

% Diffusion Coefficient in the vadose zone
thetaa_333=thetaa^3.33;
thetaw_333=thetaw^3.33;
thetae_2=thetae^2;
Deffs=(Dair*thetaa_333/thetae_2)+(Dwat*thetaw_333/(H*thetae_2));

% Diffusion Coefficient in the capillary zone
thetaacap_333=thetaacap^3.33;
thetawcap_333=thetawcap^3.33;
thetaecap_2=thetaecap^2;
Deffcap=(Dair*thetaacap_333/thetaecap_2)+(Dwat*thetawcap_333/(H*thetaecap_2));

% Deffw= Effective diffusivity from groundwater (cm2/s)
NUM=100*Lgw;
DEN=(100*hcap/Deffcap)+(100*hv/Deffs);
Deffw=NUM/DEN;

% Groundwater: Outdoor Vapors Volatilization 
NUM=1e3*H;
DEN=1+(100*Uair*100*deltaair*Lgw*100/(Deffw*Wprime*100)) ;
VF_wamb = NUM/DEN;

beta=VF_wamb*EC*IUR*1000;
