colormap(cmap)
caxis([zmin zmax])
set(gca,'YTickLabel',[],'XTickLabel',[])
set(gca,'XColor', 'none','YColor','none')
set(gca, 'color', 'none');
box('off')
hold on; plot([massBC.X(1) massBC.X(2)],[massBC.Y(1) massBC.Y(2)],'b-')
plot(TX,TY,'k+')
scatter(OBS_X(1),OBS_Y(1),'MarkerEdgeColor','m',...
    'MarkerFaceColor',[1 1 1],...
    'Marker','o');

scatter(OBS_X(2),OBS_Y(2),'MarkerEdgeColor',[0 0 0],...
    'MarkerFaceColor',[1 1 0],...
    'Marker','square');

