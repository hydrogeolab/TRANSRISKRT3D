R=readlines('bas_orig.dat');
writelines(R(1:nlsk_bas),'bas.dat');
fid=fopen('bas.dat','at+');
fmt = repmat('%10.6i', 1, 3);
fprintf(fid, fmt,tottime,1,1);
fclose all;
