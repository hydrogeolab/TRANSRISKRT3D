findX=pdist2([activetrue.X,activetrue.Y],[pz1X,pz1Y]); [IDX1,IDX2]=sort(findX);

hold on
plot(TT(no)/365,R1_inPCE(:,IDX2(1))/beta_indoor_PCE,'-o','MarkerIndices',[1 6 11 16 21])
plot(TT(no)/365,R1_inTCE(:,IDX2(1))/beta_indoor_TCE,'-+','MarkerIndices',[1 6 11 16 21])
plot(TT(no)/365,R1_inDCE(:,IDX2(1))/beta_indoor_DCE,'-s','MarkerIndices',[1 6 11 16 21])
plot(TT(no)/365,R1_inVC(:,IDX2(1))/beta_indoor_VC,'-+','MarkerIndices',[1 6 11 16 21])

xlim([0 25])
