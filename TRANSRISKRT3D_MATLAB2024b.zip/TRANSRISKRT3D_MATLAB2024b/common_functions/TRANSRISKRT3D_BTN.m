% this script creates a BTN file for all phases after the initial one
% (aph1 = "after phase 1")
% ________________________________________________________________________________
%                       WARNING
% this script uses the following default settings:
%  - number of lines cloning the original file: 6754
% please adjust the script to your own case study!
% ________________________________________________________________________________
R=readlines('rt3dbtn_orig.dat');
writelines(R(1:nlsk_btn),'rt3dbtn.dat');
fid=fopen('rt3dbtn.dat','at+');
fmt = repmat('%14.6E',1,15);
    
for ns=1:6
    ucnfile=horzcat('rt3d00',num2str(ns),'_',num2str(nph-1),'.ucn');
    C=TRANSRISKRT3D_read_ucn(ucnfile,numoutputs_old);
    wherenodata=C==C(1,1);
    Cdata=min(C(wherenodata==0));
    C(wherenodata)=Cdata;
    a=C'; Cc=a(:);
    Cn=zeros(nrps,15);
    inic=1;
    endc=15;
    for nc=1:nrps
        Cn(nc,:)=Cc(inic:endc,1);
         inic=inic+15;
        endc=endc+15;
    end

    fprintf(fid,'%s\n','       100         1(15G14.0)                   -1  A13. Starting concentration in layer  1 for species # 1PCE (mobile)                                                                    ');
    for n=1:size(Cn,1)
        fprintf(fid,fmt,Cn(n,:));
        fprintf(fid, '\n');
    end
end

fprintf(fid,'%s\n','     1E+30       .05');
fprintf(fid,'%s\n','         0         0         0         0         T');

fmt = repmat('%10.6i', 1, 1);

fprintf(fid, fmt,numoutputs);fprintf(fid, '\n');
counto=0;
for no=1:numoutputs
    counto=counto+1;
    fprintf(fid, fmt,output_time(no));
    if counto==8; fprintf(fid, '\n'); counto=0;end
end
if counto>0; fprintf(fid, '\n'); end
fprintf(fid,'%s\n','         0         1');
fprintf(fid,'%s\n','         T         1');
fprintf(fid,'%i%s\n',tottime,'         1         1');
fprintf(fid,'%s\n','         0     50000         1         0');

fclose all;

