function deleteCopiedDataFiles(fileList)
% deleteCopiedDataFiles Deletes a list of data files from current directory.
%
%   deleteCopiedDataFiles(fileList)
%
%   fileList - Cell array of file names to delete from pwd

    if nargin == 0 || isempty(fileList)
        warning('No data files specified to delete.');
        return;
    end

    deletedCount = 0;

    for k = 1:length(fileList)
        filePath = fullfile(pwd, fileList{k});
        if exist(filePath, 'file') == 2
            delete(filePath);
            fprintf('Deleted: %s\n', filePath);
            deletedCount = deletedCount + 1;
        else
            fprintf('File not found (skipped): %s\n', filePath);
        end
    end

    fprintf('Deleted %d data files.\n', deletedCount);
end
