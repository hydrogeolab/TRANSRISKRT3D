findX=pdist2([activetrue.X,activetrue.Y],[pz1X,pz1Y]); [IDX1,IDX2]=sort(findX);

cumsum_R1_inPCE=cumsum(R1_inPCE);
cumsum_R1_inTCE=cumsum(R1_inTCE);
cumsum_R1_inDCE=cumsum(R1_inDCE);
cumsum_R1_inVC=cumsum(R1_inVC);
cumsum_R1_in=cumsum_R1_inPCE+cumsum_R1_inTCE+cumsum_R1_inDCE+cumsum_R1_inVC;

%adding R(t=0)=0 in the plots
TTo=[0; TT(no)]/365;

hold on
plot(TTo,[0;cumsum_R1_inPCE(:,IDX2(1))],'-o','MarkerIndices',[1 6 11 16 21 26])
plot(TTo,[0;cumsum_R1_inTCE(:,IDX2(1))],'-+','MarkerIndices',[1 6 11 16 21 26])
plot(TTo,[0;cumsum_R1_inDCE(:,IDX2(1))],'-s','MarkerIndices',[1 6 11 16 21 26])
plot(TTo,[0;cumsum_R1_inVC(:,IDX2(1))],'-+','MarkerIndices',[1 6 11 16 21 26])
plot(TTo,[0;cumsum_R1_in(:,IDX2(1))],'--','LineWidth',2)

xlim([0 25])
