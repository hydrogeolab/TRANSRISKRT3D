function deleteCopiedFiles(fileList)
% deleteCopiedFiles Deletes a list of files from the current directory.
%
%   deleteCopiedFiles(fileList)
%
%   fileList - Cell array of file names to delete from pwd

    if nargin == 0 || isempty(fileList)
        warning('No files specified to delete.');
        return;
    end

    deletedCount = 0;

    for k = 1:length(fileList)
        filePath = fullfile(pwd, fileList{k});
        if exist(filePath, 'file') == 2
            delete(filePath);
            fprintf('Deleted: %s\n', filePath);
            deletedCount = deletedCount + 1;
        else
            fprintf('File not found (skipped): %s\n', filePath);
        end
    end

    fprintf('Deleted %d files.\n', deletedCount);
end