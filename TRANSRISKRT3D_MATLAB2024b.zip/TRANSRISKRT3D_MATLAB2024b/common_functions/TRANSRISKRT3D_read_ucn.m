function C=TRANSRISKRT3D_read_ucn(ucn2read,numoutputs)

fid_1=fopen(ucn2read,'rb');

NTRANS=fread(fid_1,1,'int32');
KSTP=fread(fid_1,1,'int32');
KPER=fread(fid_1,1,'int32');
TIME2=fread(fid_1,1,'float32');
desc = fread(fid_1, [16,1], '*char')';
NCOL=fread(fid_1,1,'int32');
NROW=fread(fid_1,1,'int32');
ILAY=fread(fid_1,1,'int32');

count=0;

TT=zeros(numoutputs,1);
Ct=zeros(numoutputs,1);

C=zeros(NROW,NCOL,ILAY);
for K=1:ILAY
    for I=1:NROW
        for J=1:NCOL
            count=count+1;
            Cnow=fread(fid_1,1,'float32');
            C(I,J,K)=Cnow;
        end
    end
end

if numoutputs>1

    for t=2:numoutputs
        NTRANS=fread(fid_1,1,'int32');
        KSTP=fread(fid_1,1,'int32');
        KPER=fread(fid_1,1,'int32');
        TIME2=fread(fid_1,1,'float32');
        desc = fread(fid_1, [16,1], '*char')';
        NCOL=fread(fid_1,1,'int32');
        NROW=fread(fid_1,1,'int32');
        ILAY=fread(fid_1,1,'int32');
        
        C=zeros(NROW,NCOL,ILAY);
        for K=1:ILAY
            for I=1:NROW
                for J=1:NCOL
                    count=count+1;
                    Cnow=fread(fid_1,1,'float32');
                    C(I,J,K)=Cnow;
                end
            end
        end
    end
end

fclose(fid_1);

